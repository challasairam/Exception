package com.cg.miniproject.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.exception.HotelException;
import com.cg.miniproject.util.DBConnection;

public class HotelBookingDaoImpl implements IHotelBookingDao{
	boolean b,result=false;
	@Override
	public boolean register(User user) throws HotelException
	{

		try {
			
			
			Connection conn = DBConnection.getConnection();	
			
			PreparedStatement preparedStatement=null;		
			
			
			int queryResult;
				
				preparedStatement=conn.prepareStatement(IQueryMapper.QUERY1);

					
				preparedStatement.setString(1,user.getPassword());
				preparedStatement.setString(2,user.getRole());	
				preparedStatement.setString(3,user.getUserName());		
				preparedStatement.setString(4,user.getMobileNo());			
				preparedStatement.setString(5,user.getPhone());
				preparedStatement.setString(6,user.getAddress());			
				preparedStatement.setString(7,user.getEmail());			
				
				queryResult=preparedStatement.executeUpdate();
			if(queryResult>0)
				b=true;
			
		} 
		catch (SQLException e) {
			
			throw new HotelException("Sorry Registration Failed !!!");
		}
		return b;
	}
	public boolean login(User user) throws HotelException
	{

		try {
			
			
			Connection conn = DBConnection.getConnection();	
			
			PreparedStatement ps = conn.prepareStatement(IQueryMapper.QUERY2);
			 ps.setString(1,user.getUserName());
			 ps.setString(2,user.getPassword());
			 ps.setString(3, user.getRole());
			 
			 ResultSet resultSet= ps.executeQuery();
			if(resultSet.isBeforeFirst())
			{
				b=true;
			}
			
				
					// TODO Auto-generated method stub
		} 
		catch (SQLException e) {
			
			throw new HotelException("Login Failed.Please login Again !!!");
		}
		return b;
	}
	
	@Override
	public boolean addHotels(Hotel hotel) throws HotelException{
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(IQueryMapper.QUERY3);
			preparedStatement.setString(1,hotel.getHotelId());
			preparedStatement.setString(2, hotel.getHotelName());
			preparedStatement.setString(3, hotel.getAddress());
			preparedStatement.setString(4, hotel.getDescription());
			preparedStatement.setString(5, hotel.getCity());
			preparedStatement.setDouble(6, hotel.getAvgRatePerNight());
			int rows_updated=preparedStatement.executeUpdate();
			if(rows_updated>0)
				result=true;
		} catch (SQLException e) {
			
			throw new HotelException("Tehnical problem occured while adding !!!");
		}
		
		return result;
	}
	@Override
	public boolean deleteHotel(String id) throws HotelException{
		Connection connection=DBConnection.getConnection();
		
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(IQueryMapper.QUERY4);
			preparedStatement.setString(1, id);
			int rows_updated=preparedStatement.executeUpdate();
			if(rows_updated>0)
				result=true;
		} catch (SQLException e) {
			
			throw new HotelException("Tehnical problem occured while deleting!!!");
		}
		return result;
	}
	@Override
	public boolean addRooms(RoomDetails roomDetails) throws HotelException{
		try {
			System.out.println(roomDetails.getRoomType());
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(IQueryMapper.QUERY5);
			preparedStatement.setString(1,roomDetails.getHotelId());
			preparedStatement.setString(2, roomDetails.getRoomId());
			preparedStatement.setString(3, roomDetails.getRoomNo());
			preparedStatement.setString(4, roomDetails.getRoomType());
			preparedStatement.setDouble(5, roomDetails.getPerNightRate());
			preparedStatement.setString(6, roomDetails.getAvailability());
			int rows_updated=preparedStatement.executeUpdate();
			if(rows_updated>0)
				result=true;
		} catch (SQLException e) {
			
			throw new HotelException("Tehnical problem occured while adding rooms!!!");
		}
		
		return result;
	}
	@Override
	public boolean deleteRooms(String id) throws HotelException{
	Connection connection=DBConnection.getConnection();
		
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(IQueryMapper.QUERY6);
			preparedStatement.setString(1, id);
			int rows_updated=preparedStatement.executeUpdate();
			if(rows_updated>0)
				result=true;
		} catch (SQLException e) {
			
			throw new HotelException("Tehnical problem occured while deleting rooms!!!");
		}
		return result;
	}
	@Override
	public ArrayList<BookingDetails> retrieveBookings(String hotelId) throws HotelException{
		ArrayList<BookingDetails> list=new ArrayList<BookingDetails>();
	Connection connection=DBConnection.getConnection();
		
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(IQueryMapper.QUERY7);
			preparedStatement.setString(1, hotelId);
			preparedStatement.executeQuery();
			ResultSet resultSet=preparedStatement.getResultSet();
			if(!resultSet.isBeforeFirst())
				System.err.println("No data found with given hotel id");
			while(resultSet.next())
			{
				/*System.out.println("In loop");*/
				BookingDetails details=new BookingDetails();
				details.setBookingId(resultSet.getString(1));
				details.setRoomId(resultSet.getString(2));
				details.setUserId(resultSet.getString(3));
				details.setBookedFrom(resultSet.getString(4));
				details.setBookedTo(resultSet.getString(5));
				details.setNoOfAdults(resultSet.getInt(6));
				details.setNoOfChildren(resultSet.getInt(7));
				details.setAmount(resultSet.getDouble(8));
				list.add(details);
			}
			}
		
		catch(Exception e)
		{
			throw new HotelException("Tehnical problem occured !!!");
		}
		return list;
	}

	@Override
	public ArrayList<BookingDetails> retrieveBookings(LocalDate date) throws HotelException{
	
		
		ArrayList<BookingDetails> list=new ArrayList<BookingDetails>();
		Connection connection=DBConnection.getConnection();
			
			try {
				PreparedStatement preparedStatement=connection.prepareStatement(IQueryMapper.QUERY8);
				System.out.println(Date.valueOf(date));
				preparedStatement.setString(1, Date.valueOf(date).toString());
				preparedStatement.setString(2, Date.valueOf(date).toString());
				preparedStatement.executeQuery();
				ResultSet resultSet=preparedStatement.getResultSet();
				if(!resultSet.isBeforeFirst())
					System.err.println("No data found for specified date");
				
				while(resultSet.next())
				{
					
					BookingDetails details=new BookingDetails();
					details.setBookingId(resultSet.getString(1));
					details.setRoomId(resultSet.getString(2));
					details.setUserId(resultSet.getString(3));
					details.setBookedFrom(resultSet.getString(4));
					details.setBookedTo(resultSet.getString(5));
					details.setNoOfAdults(resultSet.getInt(6));
					details.setNoOfChildren(resultSet.getInt(7));
					details.setAmount(resultSet.getDouble(8));
					list.add(details);
				}
				}
			
			catch(Exception e)
			{
				
				throw new HotelException("Tehnical problem occured !!!");
			}
			return list;
		
		
	}
	
	
	public ArrayList<Hotel> getHotelList() throws HotelException {
		ArrayList<Hotel> list = new ArrayList<Hotel>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY9);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Hotel hotel = new Hotel();
				hotel.setCity(resultSet.getString(1));
				hotel.setHotelName(resultSet.getString(2));
				hotel.setHotelId(resultSet.getString(3));
				list.add(hotel);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new HotelException("Tehnical problem occured !!!");
		}
		return list;
	}

	@Override
	public ArrayList<RoomDetails> getRoomDetails(String id) throws HotelException{
		// TODO Auto-generated method stub
		ArrayList<RoomDetails> details = new ArrayList<RoomDetails>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY10);
			preparedStatement.setString(1, id);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				RoomDetails roomDetails = new RoomDetails();
				roomDetails.setHotelId(resultSet.getString(1));
				roomDetails.setRoomId(resultSet.getString(2));
				roomDetails.setRoomNo(resultSet.getString(3));
				roomDetails.setRoomType(resultSet.getString(4));
				roomDetails.setPerNightRate(resultSet.getDouble(5));
				roomDetails.setAvailability(resultSet.getString(6));
				details.add(roomDetails);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new HotelException("Tehnical problem occured !!!");
		}
		return details;
	}

	@Override
	public boolean insertBookingDetails(BookingDetails bookingDetails) throws HotelException{
		// TODO Auto-generated method stub
		boolean result=false;
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate startDate = LocalDate.parse(bookingDetails.getBookedFrom(), dateFormat);
		LocalDate endDate = LocalDate.parse(bookingDetails.getBookedTo(), dateFormat);
		Period period = Period.between(startDate, endDate);
		Integer diff = period.getDays();
		User user = new User();
		//System.out.println(diff + amount);
		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		//int res = 0;
		try {
			PreparedStatement statement = connection.prepareStatement(IQueryMapper.QUERY11);
			statement.setString(1,bookingDetails.getRoomId());
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
			RoomDetails details = new RoomDetails();
			details.setPerNightRate(resultSet.getDouble(1));
			Double amount = details.getPerNightRate() * diff;
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY12);
			preparedStatement.setString(1,bookingDetails.getRoomId());
			preparedStatement.setString(2, bookingDetails.getUserId());
			preparedStatement.setDate(3, Date.valueOf(startDate)); 
			preparedStatement.setDate(4,Date.valueOf(endDate));
			preparedStatement.setLong(5, bookingDetails.getNoOfAdults());
			preparedStatement.setLong(6, bookingDetails.getNoOfChildren());
			preparedStatement.setDouble(7, amount);
			int rowsUpdated=preparedStatement.executeUpdate();
			if(rowsUpdated>0)
			{
			PreparedStatement preparedStatement2=connection.prepareStatement(IQueryMapper.QUERY13);
			preparedStatement2.setString(1, bookingDetails.getRoomId());
			preparedStatement2.executeUpdate();
			result=true;
			}
			}
			//System.out.println(res);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new HotelException("Insertion Failed!!!");
		}
		return result;
	}
	
	@Override
	public User fetchUserId(User user) throws HotelException {
		User userdetails=new User();
		Connection connection=DBConnection.getConnection();
		try {
			
			PreparedStatement preparedStatement=connection.prepareStatement(IQueryMapper.QUERY14);
			preparedStatement.setString(1, user.getUserName());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setString(3, user.getRole());
			ResultSet resultSet=preparedStatement.executeQuery();
			
			while(resultSet.next())
			{
				
				userdetails.setUserId(resultSet.getString(1));
				
			}
		} catch (SQLException e) {
			
			throw new HotelException("Failed in Fetching the details!!!");
		}
		return userdetails;
	}
	@Override
	public boolean validatename(User user) throws HotelException {
		boolean res = false;
		Connection connection = DBConnection.getConnection();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.QUERY16);
			preparedStatement.setString(1, user.getUserName());
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				res=true;
			}
			
		} catch (SQLException e) {
			throw new HotelException("Same name exists");
		}
		return res;
	}
}
